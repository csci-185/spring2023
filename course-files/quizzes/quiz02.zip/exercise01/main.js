function showFox() {
    // your code here...
    console.log('Change image and paragraph to fox...');
}

function showLion() {
    // your code here...
    console.log('Change image and paragraph to lion...');
}

function showTiger() {
    // your code here...
    console.log('Change image and paragraph to tiger...');
}

function showZebra() {
    // your code here...
    console.log('Change image and paragraph to zebra...');
}

