
function makeRed() {
    // your code here...
    console.log('Change background to red');
    document.querySelector('body').style.backgroundColor = 'red';
};

function makeBlue() {
    // your code here...
    console.log('Change background to blue');
};

function makePink() {
    // your code here...
    console.log('Change background to pink');
};

function makeOrange() {
    // your code here...
    console.log('Change background to orange');
};

